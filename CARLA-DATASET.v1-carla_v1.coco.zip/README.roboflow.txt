
CARLA-DATASET - v1 carla_v1
==============================

This dataset was exported via roboflow.ai on January 30, 2022 at 11:28 AM GMT

It includes 1864 images.
Vehicle-Bike-Motobike-Light-Sign are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)

No image augmentation techniques were applied.


